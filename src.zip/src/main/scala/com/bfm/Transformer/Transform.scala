
package com.bfm.transform

import com.bfm.spark.SparkApplication
import com.bfm.util._
import org.apache.log4j.Logger
import org.apache.spark.sql.DataFrame

trait Transform  extends SparkApplication[TransformInput]{
  /*
     This trait is to facilitate -
          transformations
          validations
   */
  def transformations(df:DataFrame) : DataFrame

  def validate(df:DataFrame) : DataFrame

  def write(df: DataFrame, params: TransformInput)
}

abstract class TransformApp extends Transform {
  lazy val logger: Logger = Logger.getLogger("com.bfm")
}