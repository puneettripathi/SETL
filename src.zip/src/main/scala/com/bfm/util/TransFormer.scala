// This is work in Progress

package com.bfm.util

import org.apache.spark.sql.SQLContext
import org.apache.spark.{Logging, SparkContext}
import scopt.OptionParser
import org.json4s._
import org.json4s.jackson.JsonMethods._

case class TransformInput (input: String = "",
                           output: String = "",
                           config: String = "",
                           numPartitions: Int = 500
                          )
object TransformInputParser extends OptionParser[TransformInput]("SimpleReader") {
  head("SimpleReader", "0.1.0")

  opt[String]('i', "input")
    .action((x, c) => c.copy(input = x))
    .text("Path of input dataset")

  opt[String]('o', "output")
    .action((x, c) => c.copy(output = x))
    .text("output path for the parquet data set")

  opt[String]('c', "config")
    .action((x, c) => c.copy(config = x))
    .text("comma separated list of paths to schema files")
}


class TransFormer(sc: SparkContext) extends Utils with Logging {

  val sqlContext = SQLContext.getOrCreate(sc)


  def jsonStrToMap(jsonStr: String): Map[String, List[Map[String, String]]] = {
    // returns a Map
    parse(jsonStr).values.asInstanceOf[Map[String, List[Map[String, String]]]]
  }

  val transformConfig ="""{
                        "validation": [],
                        "transformations": [{"Eval_Date":"date_format(to_date(from_unixtime(unix_timestamp(col('eval_date'), 'ddMMyyyy'), 'yyyy-MM-dd')),'yyyyMMdd')"}]
                        }"""

  def tranformationObject(jsonPath: String, key: String ="transformations") = {
    val parsedJson = jsonStrToMap(jsonPath)(key)
    for (k <- parsedJson) {
      k.keys
    }

  }

}
