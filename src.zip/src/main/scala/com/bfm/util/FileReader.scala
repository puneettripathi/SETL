package com.bfm.util

import java.io._
import java.util.zip.ZipInputStream

import org.apache.spark.input.PortableDataStream
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.{Row, DataFrame, SQLContext}
import org.apache.spark.{Logging, SparkContext}
import org.apache.hadoop.fs.{FileSystem, FileUtil, LocatedFileStatus, Path}

class FileReader(sc: SparkContext) extends Utils with Logging {

  val sqlContext = SQLContext.getOrCreate(sc)

  def readZipFile(fileName: String): RDD[String] = {
    log.info(s"reading Zip file ${fileName} to spark RDD")
    val ziprdd = sc.binaryFiles(fileName).flatMap { case (name: String, content: PortableDataStream) =>
      val zis = new ZipInputStream(content.open)
      Stream.continually(zis.getNextEntry)
        .takeWhile(_ != null)
        .flatMap { _ =>
          val br = new BufferedReader(new InputStreamReader(zis))
          Stream.continually(br.readLine()).takeWhile(_ != null)
        }
    }
    ziprdd
  }

  def csvToDF(filePath: String, schema: StructType, delimiter: String = "|" ,firstRowHeader: String = "false") : DataFrame = {
    log.info(s"reading CSV file ${filePath} to spark DataFrame")
    sqlContext.read
      .format("com.databricks.spark.csv")
      .option("delimiter", delimiter)
      .option("header", firstRowHeader)
      .schema(schema).load(filePath)
  }

  def parquetReaderToDF(filePath: String, schema: StructType ) : DataFrame = {
    log.info(s"reading CSV file ${filePath} to spark DataFrame")
    sqlContext.read
      .format("parquet")
      .schema(schema).load(filePath)
  }

  def readFixedLengthFile(filePath : String, splits: List[(Int, Int)]) ={
    val textRDD = sc.textFile(filePath)
    def f(s:String) = splits map { case (a,b) => s.substring(a-1,b) }
    textRDD.map(f).map(a=>Row.fromSeq(a))
  }

}