package com.bfm.util

import scopt.OptionParser

case class InputParams(input: String = "",
                       output: String = "",
                       includeFileNameCol: Boolean = false,
                       schema: Seq[String] = Seq[String](),
                       delimiter: Char = ',',
                       numPartitions: Int = 500
                      )

object InputParamsParser extends OptionParser[InputParams]("SimpleReader") {
  head("SimpleReader", "0.1.0")

  opt[String]('i', "input")
    .action((x, c) => c.copy(input = x))
    .text("comma separated list of paths to CSVs to merge, surround a path with () to take the most recent CSV" +
      " matching that path")

  opt[String]('o', "output")
    .action((x, c) => c.copy(output = x))
    .text("output path for the parquet data set")

  opt[Unit]("includeFileNameCol")
    .action((_, c) => c.copy(includeFileNameCol = true))

  opt[String]('s', "schema")
    .action((x, c) => c.copy(schema = x.split(",")))
    .text("comma separated list of paths to schema files")

  opt[String]('d', "delimiter")
    .action { (x, c) =>
      require(x.length == 1, "delimiter has to be one character only")
      c.copy(delimiter = x.charAt(0))
    }
    .text("string to use to split files")
}

