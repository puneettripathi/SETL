package com.bfm.util

import org.apache.hadoop.fs.{FileStatus, FileSystem, FileUtil, LocatedFileStatus, Path}
import org.apache.hadoop.conf.Configuration
import org.apache.spark.Logging

class Utils extends Logging {
  /*
  This class is implementation of all Generic Utilities that are useful for facilitating the processing the data
  It provide with Hadoop Filisystem variable
  Functions:
     listDir -> returns list of files in a Hadoop Directory
     mergeFiles -> merges files in a directory to creates 1 file
     fixStringSplitter -> Splits Fixed width string on multiple positions provided in "splits", return list of split strings
   */

  val conf = new Configuration()

  lazy val fs: FileSystem = FileSystem.get(conf)

  // Function to create list of files in a directory
  def listDir(path: String): Seq[LocatedFileStatus] = {
    new Iterator[LocatedFileStatus] {
      private val hdfsFilesIt = fs.listFiles(new Path(path), false)

      override def hasNext: Boolean = hdfsFilesIt.hasNext

      override def next: LocatedFileStatus = hdfsFilesIt.next
    }.toList
  }

  // Merge multiple Text files in a directory as one
  def mergeFiles(srcPath: String, dstPath: String): Unit = {
    FileUtil.copyMerge(fs, new Path(srcPath), fs, new Path(dstPath), true, conf, null)
  }

  // Splits string on multiple fixed indices
  def fixStringSplitter(indices: List[(Int, Int)], s:String): List[String] = {
    indices map { case (a,b) => s.substring(a-1,b) }
  }

  def archiveFiles(source: String, archive: String ="") = {
    // create source path and filesystem
    val srcPath: Path = new Path(source)
    val srcFs =FileSystem.get(srcPath.toUri,conf)

    // create archive path and filesystem
    val archPath = if (archive == "") new Path(source.lastIndexOf("/") + "/archive") else new Path(archive)

    // check is archive path exists, if not create
    val archPathExists = fs.exists(new Path(archive))
    if (archPathExists == false) fs.mkdirs(archPath) else None
    val archFs =FileSystem.get(archPath.toUri,conf)

    val status:Array[FileStatus] = fs.listStatus(srcPath)

    // move files if exist in source dir
    if (status.length>0) {
      status.foreach(f => {
        log.info("My files: " + f.getPath)
        FileUtil.copy(srcFs, f.getPath, archFs, archPath, true, conf)
        log.info("Files moved !!" + f.getPath)
      }
      )}
    else{
      log.debug("No Files Found !!")
    }
  }
}