
package com.bfm.ChangeDataCapture

import com.bfm.spark.SparkApplication
import com.bfm.util.InputParams
import org.apache.spark.sql.DataFrame

trait ChangeDataCapture extends SparkApplication[InputParams]{

  def readToTable(inputPath: String): DataFrame

  def captureChanges(newDf: DataFrame, histDf: DataFrame): DataFrame

  def writeCDC(df:DataFrame, params: InputParams, writeMode: String = "overwrite")

}