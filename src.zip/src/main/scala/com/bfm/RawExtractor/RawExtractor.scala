package com.bfm.RawExtractor


import org.apache.spark.sql.types._
import com.bfm.spark.SparkApplication
import org.apache.spark.sql.DataFrame
import com.bfm.util._
import org.apache.log4j.Logger

trait RawExtractor extends SparkApplication[InputParams]{
  // this is the interface to Raw Parquet creation

  def readAsDF(params: InputParams, schema: StructType):DataFrame

  def writeToParquet(df: DataFrame, params: InputParams, writeMode: String)

}


// change the outlook of below app
// make it read(extract), parse, convert to DF and then write the file to FS
abstract class RawExtractorApp extends RawExtractor {
  lazy val logger: Logger = Logger.getLogger("com.bfm")
}
