package com.bfm.spark

import org.apache.spark.{Logging, SparkConf, SparkContext}
import com.typesafe.config.Config
import scopt.OptionParser
import spark.jobserver.{SparkJob, SparkJobValid, SparkJobValidation}
import org.apache.log4j.{Level, Logger}
import de.javakaffee.kryoserializers.jodatime.JodaDateTimeSerializer
import scala.reflect.ClassTag
import com.bfm.util.ReflectionHelper
import com.esotericsoftware.kryo.Kryo
import org.apache.spark.serializer.KryoRegistrator
import org.joda.time.DateTime

//  build Logger and ReflectionHelper

abstract class ScalaApplication[T: ClassTag] extends Logging {
  //
  protected val dfltConfig: T = ReflectionHelper.newCase[T]
  protected val parser: OptionParser[T]
//
  def run(config: T)
//
  def main(args: Array[String]) = {
    parser.parse(args, dfltConfig) match {
      case Some(config) => run(config)
      case None => logError("Unable to parse arguments: " + args.mkString(" "))
    }
  }
}

abstract class SparkApplication[T: ClassTag] extends ScalaApplication[T] with SparkJob {
  protected lazy val sparkConf: SparkConf = {
    val conf = new SparkConf
    if (!conf.contains("spark.master")) {
      conf.setMaster("local[2]")
    }
    if (!conf.contains("spark.app.name")) {
      conf.setAppName(getClass.getName)
    }
    // set root logging to error but maintain loanvault logging
    Logger.getRootLogger.setLevel(Level.ERROR)
    Logger.getLogger("com.bfm").setLevel(Level.INFO)
    conf.set("spark.kryo.registrator", "com.bfm.spark.ResearchPlatformKryoRegistrator")
    conf
  }

  var _sc: Option[SparkContext] = Some(new SparkContext(sparkConf))

  protected lazy val sc = _sc.get

  /**
    * function for Spark JobServer to call when it receives a request to run this class
    */
  override def runJob(p_sc: SparkContext, jobConfig: Config): Any = {
    _sc = Some(p_sc)
    main(jobConfig.getString("configs").replace("%2C", ",").split(" "))
  }

  /**
    * function for Spark JobServer to ensure sc is correct. I have no checks to run.
    */
  override def validate(sc: SparkContext, config: Config): SparkJobValidation = SparkJobValid

  override def main(args: Array[String]) = {
    if (_sc.isEmpty) {
      _sc = Some(new SparkContext(sparkConf))
    }
    super.main(args)
  }
}

class ResearchPlatformKryoRegistrator extends KryoRegistrator {
  override def registerClasses(kryo: Kryo) {
    kryo.register(classOf[DateTime], new JodaDateTimeSerializer)
  }
}